Bosch GWS 10.8V / 12V Guide — вариант под профиль 45.6 x 12.5 мм (Т-паз 19.2)
На основе "Bosch GWS 10.8V / 12V Guide - Remix" by Freeman33, https://www.thingiverse.com/thing:5262557 (CC BY)

Печать (все STL уже уложены на стол в нужной ориентации):
  
  1_Guide_Body_Profile45_x1.stl   — корпус, поддержки только от стола под площадкой болгарки
  2_Guide_Bracket_x1.stl          — кронштейн, на боку, без поддержек
  
